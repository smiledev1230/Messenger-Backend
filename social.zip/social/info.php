<?php
// Software Name
$name = 'phpSocial';

// Software Author
$author = 'phpSocial';

// Software URL
$url = 'http://phpsocial.com';

// Software Version
$version = '4.7.0';
?>