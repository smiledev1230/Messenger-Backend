/*!
 * This file can contain your JS code
 */

function lorem() {
	
}