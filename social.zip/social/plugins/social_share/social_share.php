<?php
function social_share() {

}
?>