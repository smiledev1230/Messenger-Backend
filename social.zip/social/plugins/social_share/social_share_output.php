<?php
// Load the configuration file
require_once(__DIR__ .'/config.php');

function social_share_output($values) {
	$value	= $values['value'];
	$type	= $values['type'];
	$id		= $values['id'];
	global $CONF;
	
   /**
    *
	* array map: css class => array(service name, js value)
	*
	*/
	
	$list = array(
		($GLOBALS['ss_facebook'] ? array('name' => 'Facebook', 'value' => 'facebook') : ''),
		($GLOBALS['ss_twitter'] ? array('name' => 'Twitter', 'value' => 'twitter') : ''),
		($GLOBALS['ss_gplus'] ? array('name' => 'Google+', 'value' => 'gplus') : ''),
		($GLOBALS['ss_pinterest'] ? array('name' => 'Pinterest', 'value' => 'pinterest') : ''),
		($GLOBALS['ss_tumblr'] ? array('name' => 'Tumblr.', 'value' => 'tumblr') : ''),
		($GLOBALS['ss_vkontakte'] ? array('name' => 'VKontakte', 'value' => 'vkontakte') : ''),
		($GLOBALS['ss_reddit'] ? array('name' => 'Reddit', 'value' => 'reddit') : ''),
		($GLOBALS['ss_linkedin'] ? array('name' => 'LinkedIn', 'value' => 'linkedin') : ''),
		($GLOBALS['ss_digg'] ? array('name' => 'digg', 'value' => 'digg') : ''),
		($GLOBALS['ss_delicious'] ? array('name' => 'Delicious', 'value' => 'delicious') : ''),
		($GLOBALS['ss_evernote'] ? array('name' => 'Evernote', 'value' => 'evernote') : ''),
		($GLOBALS['ss_yummly'] ? array('name' => 'Yummly', 'value' => 'yummly') : ''),
		($GLOBALS['ss_email'] ? array('name' => 'Email', 'value' => 'email') : ''),
		($GLOBALS['ss_yahoo'] ? array('name' => 'Yahoo', 'value' => 'yahoo') : ''),
		($GLOBALS['ss_gmail'] ? array('name' => 'Gmail', 'value' => 'gmail') : ''),
		($GLOBALS['ss_whatsapp'] ? array('name' => 'WhatsApp', 'value' => 'whatsapp') : ''),
		($GLOBALS['ss_viber'] ? array('name' => 'Viber', 'value' => 'viber') : '')
	);

	$buttons = '';
	// Get the available buttons
	foreach($list as $social) {
		if($social) {
			$buttons .= '<div class="share-icon-container"><div class="share-icon-padding"><a id="'.$social['value'].'-share" title="'.$social['name'].'" onclick="share_social(\''.$social['value'].'\', \''.urlencode(permalink($CONF['url'].'/index.php?a=post&m='.$id)).'\', '.$id.')" rel="nofollow"><div class="share-social-icon '.$social['value'].'-icon"></div></a></div></div>';
		}
	}
	
	// If there's no button to output
	if(empty($buttons)) {
		return false;
	}
	
	// Output the social buttons
	$output = '
	<div class="social-share-container">
		<div class="social-share-content">
			'.$buttons.'
		</div>
	</div>
	<div class="message-divider"></div>';

	return $output;
}
?>