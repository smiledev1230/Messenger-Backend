<?php

// Facebook
$GLOBALS['ss_facebook'] = true;

// Twitter
$GLOBALS['ss_twitter'] = true;

// Google+
$GLOBALS['ss_gplus'] = true;

// Pinterest
$GLOBALS['ss_pinterest'] = true;

// Tumblr
$GLOBALS['ss_tumblr'] = true;

// Email
$GLOBALS['ss_email'] = true;

// VKontakte
$GLOBALS['ss_vkontakte'] = true;

// Reddit
$GLOBALS['ss_reddit'] = true;

// LinkedIn
$GLOBALS['ss_linkedin'] = true;

// WhatsApp
$GLOBALS['ss_whatsapp'] = true;

// Viber
$GLOBALS['ss_viber'] = true;

// Digg
$GLOBALS['ss_digg'] = true;

// Delicious
$GLOBALS['ss_delicious'] = true;

// Evernote
$GLOBALS['ss_evernote'] = true;

// Yummly
$GLOBALS['ss_yummly'] = true;

// Yahoo
$GLOBALS['ss_yahoo'] = true;

// Gmail
$GLOBALS['ss_gmail'] = true;

?>