<?php
// Plugin Name
$name = 'Video Call';

// Plugin Author
$author = 'phpSocial';

// Plugin URL
$url = 'http://phpsocial.com';

// Plugin Version
$version = '1.0.7';

// Plugin Type
$type = '89ed';
?>