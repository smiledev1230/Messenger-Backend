<?php

// Twilio Account SID
$GLOBALS['video_call_twilio_account_sid'] = 'AC4c5f0580e6392568fd2bac254cb6bdf5';

// Twilio API Key ID
$GLOBALS['video_call_twilio_key_sid'] = 'SK7dd58e329b8d9f88264cf12bf7ae044f';

// Twilio API Key Secret
$GLOBALS['video_call_twilio_key_secret'] = 'anm92pRJuld9hXipk0Rhwa5Y2fw9uv4A';

// Dial Time (The maximum number of seconds the dial should last)
$GLOBALS['video_call_dial_time'] = '30';

// Call Time (The maximum number of hours a call should last)
$GLOBALS['video_call_call_time'] = '12';

?>