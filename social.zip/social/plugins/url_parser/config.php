<?php

// Your API Key
$GLOBALS['url_parser_api_key'] = 'AIzaSyBNfYy8klhcOIqxdV8Iha1jOGBD4EFAzTA';

?>