<?php
// Load the configuration file
require_once(__DIR__ .'/config.php');

function url_parser_output($values) {
	$value		= $values['value'];
	$type		= $values['type'];
	global $CONF;
	
	// If there's no event type and there's an event value that matches "url:"
	if(empty($type) && substr($value, 0, 4) == 'url:') {
		$url = json_decode(str_replace('url:', '', $value), true);

		// Get the short form of the URL
		$url['url_short'] = parse_url($url['url'], PHP_URL_HOST);
		
		// If there's an image
		$url['image'] = ($url['image'] ? '<div class="link-poster"><a href="'.$url['url'].'" target="_blank" rel="nofollow"><img src="'.$CONF['url'].'/plugins/url_parser/screenshots/'.$url['image'].'"></a></div>' : '');
		
		$output = '<div class="link-container">
			'.$url['image'].'
			<div class="link-content'.($url['image'] ? '' : ' link-no-image').'">
				<div class="link-title"><a href="'.$url['url'].'" target="_blank" rel="nofollow">'.htmlentities($url['title'], ENT_QUOTES).'</a></div>
				<div class="link-description">'.htmlentities($url['description'], ENT_QUOTES).'</div>
				<div class="link-url">'.$url['url_short'].'</div></div>
				<div class="message-divider">
			</div>
		</div>';
		
		// Return the result
		return $output;
	}
}
?>