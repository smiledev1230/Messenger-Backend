<?php
// Plugin Name
$name = 'URL Parser';

// Plugin Author
$author = 'phpSocial';

// Plugin URL
$url = 'http://phpsocial.com';

// Plugin Version
$version = '1.0.4';

// Plugin Type
$type = '18';
?>