<?php
// Theme Name
$name = 'Plus';

// Theme Author
$author = 'phpSocial';

// Theme URL
$url = 'http://phpsocial.com';

// Theme Version
$version = '1.7.0';
?>