<?php
// Theme Name
$name = 'Dolphin';

// Theme Author
$author = 'phpSocial';

// Theme URL
$url = 'http://phpsocial.com';

// Theme Version
$version = '1.9.0';
?>