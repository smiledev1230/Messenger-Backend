<?php
// Plugin Name
$name = 'Lorem Ipsum';

// Plugin Author
$author = 'Author Name';

// Plugin URL
$url = 'http://example.com';

// Plugin Version
$version = '1.0.0';

// Plugin Type
$type = '12389';
?>