<?php

$LNG['plugin_lorem_example'] = 'Example';