<?php
function lorem($values) {
   /**
	* $type = '1';
	*
	* This function will be called during the Post Message event. It can be used to parse the input and insert data into the database.
	*
	* @param	array	$values		Message event values sent by the user.
	*
	*/
	
   /**
	* $type = '4';
	*
	* This function will be called on the homepage to be executed.
	*
	* @param	array	$values		Site information.
	*
	*/
}
?>